package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.Crossfade
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Eco
import androidx.compose.material.icons.filled.Factory
import androidx.compose.material.icons.filled.HelpOutline
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.CenterAlignedTopAppBar
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.audio.AudioController
import com.example.model.InitialWasteListings
import com.example.model.WasteListing
import com.example.ui.BuyerMapScreen
import com.example.ui.DownloadApkDialog
import com.example.ui.FarmerPostScreen
import com.example.ui.theme.MyApplicationTheme
import com.example.ui.theme.SfairAmberSecondary
import com.example.ui.theme.SfairGreenPrimary

enum class AppUserRole {
    FARMER,
    FACTORY_BUYER
}

class MainActivity : ComponentActivity() {
    private lateinit var audioController: AudioController

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        audioController = AudioController(this)

        setContent {
            MyApplicationTheme {
                CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                    SfairApp(audioController = audioController)
                }
            }
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        audioController.cleanUp()
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SfairApp(audioController: AudioController) {
    var currentRole by remember { mutableStateOf(AppUserRole.FARMER) }
    val listings = remember { mutableStateListOf<WasteListing>().apply { addAll(InitialWasteListings) } }
    var showDownloadDialog by remember { mutableStateOf(false) }

    Scaffold(
        topBar = {
            CenterAlignedTopAppBar(
                title = {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.Center
                    ) {
                        Surface(
                            shape = CircleShape,
                            color = SfairGreenPrimary,
                            modifier = Modifier.size(34.dp)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Text("🌾", fontSize = 18.sp)
                            }
                        }
                        Spacer(modifier = Modifier.width(8.dp))
                        Column(horizontalAlignment = Alignment.Start) {
                            Text(
                                text = "سفير | Sfair",
                                fontSize = 17.sp,
                                fontWeight = FontWeight.Bold,
                                color = SfairGreenPrimary
                            )
                            Text(
                                text = "تجارة المخلفات الزراعية بالصوت",
                                fontSize = 11.sp,
                                color = Color.Gray
                            )
                        }
                    }
                },
                actions = {
                    IconButton(
                        onClick = { showDownloadDialog = true },
                        modifier = Modifier.testTag("download_apk_top_btn")
                    ) {
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = Color(0xFFE8F5E9),
                            modifier = Modifier.size(36.dp)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Icon(
                                    imageVector = Icons.Default.Download,
                                    contentDescription = "تحميل التطبيق على الهاتف",
                                    tint = SfairGreenPrimary,
                                    modifier = Modifier.size(20.dp)
                                )
                            }
                        }
                    }
                },
                colors = TopAppBarDefaults.centerAlignedTopAppBarColors(
                    containerColor = Color.White
                )
            )
        },
        bottomBar = {
            NavigationBar(
                containerColor = Color.White,
                tonalElevation = 8.dp
            ) {
                NavigationBarItem(
                    selected = currentRole == AppUserRole.FARMER,
                    onClick = {
                        audioController.stopPlaying()
                        currentRole = AppUserRole.FARMER
                    },
                    icon = {
                        Icon(
                            imageVector = Icons.Default.Mic,
                            contentDescription = "أنا مزارع"
                        )
                    },
                    label = {
                        Text(
                            text = "👨‍🌾 أنا مزارع (اعرض محصولك)",
                            fontWeight = if (currentRole == AppUserRole.FARMER) FontWeight.Bold else FontWeight.Normal
                        )
                    },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = SfairGreenPrimary,
                        selectedTextColor = SfairGreenPrimary,
                        indicatorColor = Color(0xFFE8F5E9)
                    )
                )

                NavigationBarItem(
                    selected = currentRole == AppUserRole.FACTORY_BUYER,
                    onClick = {
                        audioController.stopPlaying()
                        currentRole = AppUserRole.FACTORY_BUYER
                    },
                    icon = {
                        Icon(
                            imageVector = Icons.Default.Factory,
                            contentDescription = "أنا مصنع"
                        )
                    },
                    label = {
                        Text(
                            text = "🏭 أنا مصنع (خريطة العروض)",
                            fontWeight = if (currentRole == AppUserRole.FACTORY_BUYER) FontWeight.Bold else FontWeight.Normal
                        )
                    },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = SfairGreenPrimary,
                        selectedTextColor = SfairGreenPrimary,
                        indicatorColor = Color(0xFFE8F5E9)
                    )
                )
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            Crossfade(targetState = currentRole, label = "roleCrossfade") { role ->
                when (role) {
                    AppUserRole.FARMER -> {
                        FarmerPostScreen(
                            audioController = audioController,
                            onOfferCreated = { newListing ->
                                listings.add(0, newListing)
                            },
                            onNavigateToBuyer = {
                                currentRole = AppUserRole.FACTORY_BUYER
                            }
                        )
                    }
                    AppUserRole.FACTORY_BUYER -> {
                        BuyerMapScreen(
                            listings = listings,
                            audioController = audioController
                        )
                    }
                }
            }
        }
    }

    if (showDownloadDialog) {
        DownloadApkDialog(onDismiss = { showDownloadDialog = false })
    }
}
