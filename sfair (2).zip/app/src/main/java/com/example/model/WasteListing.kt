package com.example.model

import androidx.compose.ui.graphics.Color

enum class WasteType(
    val titleArabic: String,
    val subtitleArabic: String,
    val iconEmoji: String,
    val badgeColor: Long,
    val avgDensityTonsPerFeddan: String
) {
    SUGARCANE_TRASH(
        titleArabic = "سفير قصب",
        subtitleArabic = "أوراق قصب السكر الجافة (السفير)",
        iconEmoji = "🌾",
        badgeColor = 0xFF2E7D32,
        avgDensityTonsPerFeddan = "3 - 5 طن/فدان"
    ),
    SUGARCANE_BAGASSE(
        titleArabic = "مصاصة قصب",
        subtitleArabic = "مخلفات عصر القصب من المعاصر والمصانع",
        iconEmoji = "🪵",
        badgeColor = 0xFF8D6E63,
        avgDensityTonsPerFeddan = "أطنان حسب المعصرة"
    ),
    RICE_STRAW(
        titleArabic = "قش أرز",
        subtitleArabic = "قش أرز مضغوط أو فرط",
        iconEmoji = "🌿",
        badgeColor = 0xFFF57F17,
        avgDensityTonsPerFeddan = "2 - 3 طن/فدان"
    ),
    CORN_STALKS(
        titleArabic = "حطب ذرة",
        subtitleArabic = "عيدان الذرة الشامية والرفيعة",
        iconEmoji = "🌽",
        badgeColor = 0xFFE65100,
        avgDensityTonsPerFeddan = "2.5 طن/فدان"
    )
}

enum class PackagingType(val arabicName: String) {
    BALED("مكبوس ببالات"),
    LOOSE("فرط في الأرض"),
    LOADED_TRAILER("محمل على مقطورة")
}

data class WasteListing(
    val id: String,
    val farmerName: String,
    val farmerPhone: String,
    val wasteType: WasteType,
    val estimatedTons: Double,
    val villageName: String,
    val governorate: String = "قنا",
    val distanceKm: Double,
    val audioDurationSeconds: Int = 18,
    val audioFileUri: String? = null,
    val voiceTranscription: String,
    val packaging: PackagingType = PackagingType.BALED,
    val hasOwnTransport: Boolean = false,
    val pricePerTonEgp: String = "سعر تفاوضي",
    val latitude: Double = 26.1551,
    val longitude: Double = 32.7214,
    val timeAgoArabic: String = "منذ ساعة",
    val isVerifiedFarmer: Boolean = true
)
