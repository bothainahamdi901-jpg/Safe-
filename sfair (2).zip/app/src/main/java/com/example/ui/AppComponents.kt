package com.example.ui

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Headphones
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.SfairAmberSecondary
import com.example.ui.theme.SfairGreenPrimary

@Composable
fun AudioWaveformVisualizer(
    isRecording: Boolean,
    amplitudes: List<Float>,
    modifier: Modifier = Modifier
) {
    val infiniteTransition = rememberInfiniteTransition(label = "waveform")
    val waveScale by infiniteTransition.animateFloat(
        initialValue = 0.3f,
        targetValue = 1.0f,
        animationSpec = infiniteRepeatable(
            animation = tween(400, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "waveScale"
    )

    Row(
        modifier = modifier
            .fillMaxWidth()
            .height(48.dp)
            .padding(horizontal = 16.dp),
        horizontalArrangement = Arrangement.Center,
        verticalAlignment = Alignment.CenterVertically
    ) {
        val barsCount = 24
        for (i in 0 until barsCount) {
            val amp = if (isRecording) {
                val base = if (i < amplitudes.size) amplitudes[i] else 0.4f
                (base * waveScale).coerceIn(0.15f, 1f)
            } else 0.2f

            Box(
                modifier = Modifier
                    .padding(horizontal = 2.dp)
                    .width(4.dp)
                    .height((38 * amp).dp)
                    .clip(RoundedCornerShape(2.dp))
                    .background(
                        if (isRecording) Color(0xFFD32F2F) else SfairGreenPrimary.copy(alpha = 0.4f)
                    )
            )
        }
    }
}

@Composable
fun AudioPlayerCard(
    audioDurationSec: Int,
    isPlaying: Boolean,
    progress: Float,
    onTogglePlay: () -> Unit,
    farmerTranscription: String? = null,
    modifier: Modifier = Modifier
) {
    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xFFE8F5E9)),
        modifier = modifier
            .fillMaxWidth()
            .border(1.dp, Color(0xFFA5D6A7), RoundedCornerShape(16.dp))
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.fillMaxWidth()
            ) {
                Surface(
                    shape = CircleShape,
                    color = if (isPlaying) Color(0xFF1B5E20) else SfairAmberSecondary,
                    modifier = Modifier.size(46.dp)
                ) {
                    IconButton(
                        onClick = onTogglePlay,
                        modifier = Modifier.testTag("play_audio_btn")
                    ) {
                        Icon(
                            imageVector = if (isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                            contentDescription = if (isPlaying) "إيقاف مؤقت" else "تشغيل التسجيل الصوتي",
                            tint = Color.White
                        )
                    }
                }

                Spacer(modifier = Modifier.width(12.dp))

                Column(modifier = Modifier.weight(1f)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = if (isPlaying) "جاري تشغيل صوت المزارع..." else "تسجيل صوتي من المزارع",
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF1B5E20)
                        )
                        Text(
                            text = "0:${String.format("%02d", audioDurationSec)}",
                            fontSize = 12.sp,
                            color = Color.Gray,
                            fontWeight = FontWeight.SemiBold
                        )
                    }

                    Spacer(modifier = Modifier.height(6.dp))

                    LinearProgressIndicator(
                        progress = { if (isPlaying) progress else 0f },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(6.dp)
                            .clip(RoundedCornerShape(3.dp)),
                        color = Color(0xFF1B5E20),
                        trackColor = Color(0xFFC8E6C9)
                    )
                }
            }

            if (!farmerTranscription.isNullOrBlank()) {
                Spacer(modifier = Modifier.height(10.dp))
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(10.dp))
                        .background(Color.White.copy(alpha = 0.9f))
                        .padding(10.dp)
                ) {
                    Row(verticalAlignment = Alignment.Top) {
                        Icon(
                            imageVector = Icons.Default.VolumeUp,
                            contentDescription = null,
                            tint = SfairAmberSecondary,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "« $farmerTranscription »",
                            fontSize = 13.sp,
                            lineHeight = 18.sp,
                            color = Color(0xFF263238),
                            fontStyle = androidx.compose.ui.text.font.FontStyle.Italic
                        )
                    }
                }
            }
        }
    }
}

fun launchPhoneCall(context: Context, phoneNumber: String) {
    try {
        val intent = Intent(Intent.ACTION_DIAL).apply {
            data = Uri.parse("tel:$phoneNumber")
        }
        context.startActivity(intent)
    } catch (e: Exception) {
        Toast.makeText(context, "تعذر فتح لوحة الاتصال: $phoneNumber", Toast.LENGTH_SHORT).show()
    }
}

fun launchWhatsApp(context: Context, phoneNumber: String, messageText: String) {
    try {
        val formattedNumber = if (phoneNumber.startsWith("0")) "+20" + phoneNumber.substring(1) else phoneNumber
        val url = "https://wa.me/$formattedNumber?text=${Uri.encode(messageText)}"
        val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url))
        context.startActivity(intent)
    } catch (e: Exception) {
        Toast.makeText(context, "تطبيق واتساب غير متاح", Toast.LENGTH_SHORT).show()
    }
}

@Composable
fun DownloadApkDialog(
    onDismiss: () -> Unit
) {
    val context = LocalContext.current

    AlertDialog(
        onDismissRequest = onDismiss,
        confirmButton = {
            Button(
                onClick = onDismiss,
                colors = ButtonDefaults.buttonColors(containerColor = SfairGreenPrimary)
            ) {
                Text("حسناً، فهمت")
            }
        },
        dismissButton = {
            OutlinedButton(
                onClick = {
                    val shareIntent = Intent(Intent.ACTION_SEND).apply {
                        type = "text/plain"
                        putExtra(
                            Intent.EXTRA_TEXT,
                            "تطبيق سفير (Sfair) لتجارة المخلفات الزراعية وسفير القصب للمزارعين والمصانع"
                        )
                    }
                    context.startActivity(Intent.createChooser(shareIntent, "مشاركة التطبيق"))
                }
            ) {
                Icon(Icons.Default.Share, contentDescription = null, modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text("مشاركة")
            }
        },
        title = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    Icons.Default.Download,
                    contentDescription = null,
                    tint = SfairGreenPrimary,
                    modifier = Modifier.size(28.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "طريقة تثبيت التطبيق على هاتفك",
                    fontWeight = FontWeight.Bold,
                    fontSize = 18.sp
                )
            }
        },
        text = {
            Column(modifier = Modifier.fillMaxWidth()) {
                Text(
                    text = "لتثبيت ملف الـ APK الخاص بتطبيق «سفير» على هاتفك المحمول مباشرة:",
                    fontSize = 14.sp,
                    lineHeight = 20.sp,
                    color = Color(0xFF37474F)
                )
                Spacer(modifier = Modifier.height(12.dp))

                StepGuideItem(
                    stepNumber = "١",
                    title = "تحميل ملف الـ APK",
                    description = "اضغط على زر القائمة أو خيار التصدير (Export / Download APK) في أعلى منصة AI Studio لتحميل ملف الحزمة مباشرة."
                )

                Spacer(modifier = Modifier.height(8.dp))

                StepGuideItem(
                    stepNumber = "٢",
                    title = "نقل الملف للهاتف",
                    description = "افتح الملف من هاتفك (عبر واتساب، أو Google Drive، أو كابل USB، أو عبر المتصفح مباشرة)."
                )

                Spacer(modifier = Modifier.height(8.dp))

                StepGuideItem(
                    stepNumber = "٣",
                    title = "السماح بالتثبيت",
                    description = "عند فتح الملف، اضغط 'تثبيت' (Install)، وإذا ظهر تنبيه الأمان، اختر 'السماح من هذا المصدر' (Install unknown apps)."
                )
            }
        }
    )
}

@Composable
fun StepGuideItem(stepNumber: String, title: String, description: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(8.dp))
            .background(Color(0xFFF1F8E9))
            .padding(8.dp),
        verticalAlignment = Alignment.Top
    ) {
        Surface(
            shape = CircleShape,
            color = SfairGreenPrimary,
            modifier = Modifier.size(24.dp)
        ) {
            Box(contentAlignment = Alignment.Center) {
                Text(
                    text = stepNumber,
                    color = Color.White,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }
        Spacer(modifier = Modifier.width(10.dp))
        Column(modifier = Modifier.weight(1f)) {
            Text(text = title, fontSize = 13.sp, fontWeight = FontWeight.Bold, color = Color(0xFF1B5E20))
            Text(text = description, fontSize = 12.sp, color = Color(0xFF455A64), lineHeight = 16.sp)
        }
    }
}
