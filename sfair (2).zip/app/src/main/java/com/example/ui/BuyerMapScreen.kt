package com.example.ui

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.FilterList
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Map
import androidx.compose.material.icons.filled.Navigation
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.NotificationsActive
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.ViewList
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.audio.AudioController
import com.example.model.WasteListing
import com.example.model.WasteType
import com.example.ui.theme.SfairAmberSecondary
import com.example.ui.theme.SfairGreenPrimary

@Composable
fun BuyerMapScreen(
    listings: List<WasteListing>,
    audioController: AudioController,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    var selectedDistanceKm by remember { mutableStateOf<Double?>(null) }
    var selectedWasteTypeFilter by remember { mutableStateOf<WasteType?>(null) }
    var selectedTab by remember { mutableStateOf(0) } // 0: Map & Radar, 1: List
    var selectedListingForDetail by remember { mutableStateOf<WasteListing?>(listings.firstOrNull()) }

    val filteredListings = listings.filter { listing ->
        val matchDistance = selectedDistanceKm == null || listing.distanceKm <= selectedDistanceKm!!
        val matchType = selectedWasteTypeFilter == null || listing.wasteType == selectedWasteTypeFilter
        matchDistance && matchType
    }

    val totalAvailableTons = filteredListings.sumOf { it.estimatedTons }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(Color(0xFFF7FAF7))
    ) {
        // Factory Proximity Alert Banner
        Card(
            shape = RoundedCornerShape(0.dp),
            colors = CardDefaults.cardColors(containerColor = Color(0xFF1B5E20)),
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 10.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        Icons.Default.NotificationsActive,
                        contentDescription = null,
                        tint = SfairAmberSecondary,
                        modifier = Modifier.size(22.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "متاح حالياً: ${totalAvailableTons.toInt()} طن مخلفات بالقرب من مصنعك",
                        color = Color.White,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold
                    )
                }

                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = Color.White.copy(alpha = 0.2f)
                ) {
                    Text(
                        text = "مصنع قوص / قنا",
                        color = Color.White,
                        fontSize = 11.sp,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                    )
                }
            }
        }

        // Distance & Waste Type Filters
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .background(Color.White)
                .padding(horizontal = 12.dp, vertical = 8.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(
                    text = "نطاق المسافة:",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFF455A64)
                )
                Spacer(modifier = Modifier.width(8.dp))

                DistanceFilterChip(label = "الكل", isSelected = selectedDistanceKm == null) {
                    selectedDistanceKm = null
                }
                Spacer(modifier = Modifier.width(6.dp))
                DistanceFilterChip(label = "١٠ كم", isSelected = selectedDistanceKm == 10.0) {
                    selectedDistanceKm = 10.0
                }
                Spacer(modifier = Modifier.width(6.dp))
                DistanceFilterChip(label = "٢٥ كم", isSelected = selectedDistanceKm == 25.0) {
                    selectedDistanceKm = 25.0
                }
                Spacer(modifier = Modifier.width(6.dp))
                DistanceFilterChip(label = "٥٠ كم", isSelected = selectedDistanceKm == 50.0) {
                    selectedDistanceKm = 50.0
                }
            }

            Spacer(modifier = Modifier.height(4.dp))

            // Waste Type Filters
            LazyRow(
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                contentPadding = PaddingValues(vertical = 4.dp)
            ) {
                item {
                    FilterChip(
                        selected = selectedWasteTypeFilter == null,
                        onClick = { selectedWasteTypeFilter = null },
                        label = { Text("جميع المخلفات (${listings.size})", fontSize = 12.sp) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = Color(0xFFE8F5E9),
                            selectedLabelColor = SfairGreenPrimary
                        )
                    )
                }
                items(WasteType.values()) { type ->
                    val count = listings.count { it.wasteType == type }
                    FilterChip(
                        selected = selectedWasteTypeFilter == type,
                        onClick = {
                            selectedWasteTypeFilter = if (selectedWasteTypeFilter == type) null else type
                        },
                        label = { Text("${type.iconEmoji} ${type.titleArabic} ($count)", fontSize = 12.sp) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = Color(0xFFE8F5E9),
                            selectedLabelColor = SfairGreenPrimary
                        )
                    )
                }
            }
        }

        // View Mode Tabs
        TabRow(
            selectedTabIndex = selectedTab,
            containerColor = Color.White,
            contentColor = SfairGreenPrimary
        ) {
            Tab(
                selected = selectedTab == 0,
                onClick = { selectedTab = 0 },
                text = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Map, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("الخريطة الذكية والرادار", fontSize = 13.sp, fontWeight = FontWeight.Bold)
                    }
                }
            )
            Tab(
                selected = selectedTab == 1,
                onClick = { selectedTab = 1 },
                text = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.ViewList, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("قائمة العروض (${filteredListings.size})", fontSize = 13.sp, fontWeight = FontWeight.Bold)
                    }
                }
            )
        }

        if (selectedTab == 0) {
            // Interactive Smart Map & Radar Canvas
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f)
                    .background(Color(0xFFE8ECE9))
            ) {
                SmartMapCanvas(
                    listings = filteredListings,
                    selectedListing = selectedListingForDetail,
                    onSelectListing = { selectedListingForDetail = it }
                )

                // Selected Listing Overlay Card on Map
                selectedListingForDetail?.let { listing ->
                    Box(
                        modifier = Modifier
                            .align(Alignment.BottomCenter)
                            .padding(12.dp)
                    ) {
                        BuyerListingCard(
                            listing = listing,
                            audioController = audioController,
                            isCompact = false
                        )
                    }
                }
            }
        } else {
            // Full Listing Feed
            LazyColumn(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f)
                    .padding(horizontal = 12.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp),
                contentPadding = PaddingValues(vertical = 12.dp)
            ) {
                items(filteredListings) { listing ->
                    BuyerListingCard(
                        listing = listing,
                        audioController = audioController,
                        isCompact = false
                    )
                }
            }
        }
    }
}

@Composable
fun DistanceFilterChip(label: String, isSelected: Boolean, onClick: () -> Unit) {
    Surface(
        shape = RoundedCornerShape(8.dp),
        color = if (isSelected) SfairGreenPrimary else Color(0xFFF1F8E9),
        modifier = Modifier.clickable(onClick = onClick)
    ) {
        Text(
            text = label,
            fontSize = 11.sp,
            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
            color = if (isSelected) Color.White else Color(0xFF1B5E20),
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
        )
    }
}

@Composable
fun SmartMapCanvas(
    listings: List<WasteListing>,
    selectedListing: WasteListing?,
    onSelectListing: (WasteListing) -> Unit
) {
    Box(modifier = Modifier.fillMaxSize()) {
        // Stylized Nile Valley GIS Map Canvas
        Canvas(modifier = Modifier.fillMaxSize()) {
            val center = Offset(size.width * 0.5f, size.height * 0.45f)
            
            // Draw Range Circles from Factory
            val radarCircles = listOf(0.25f, 0.5f, 0.75f)
            radarCircles.forEachIndexed { index, ratio ->
                drawCircle(
                    color = Color(0xFFB0BEC5).copy(alpha = 0.4f),
                    radius = size.minDimension * ratio,
                    center = center,
                    style = Stroke(
                        width = 1.5f,
                        pathEffect = PathEffect.dashPathEffect(floatArrayOf(12f, 12f), 0f)
                    )
                )
            }

            // Draw Nile River path representation
            val nilePath = androidx.compose.ui.graphics.Path().apply {
                moveTo(size.width * 0.48f, 0f)
                cubicTo(
                    size.width * 0.42f, size.height * 0.3f,
                    size.width * 0.58f, size.height * 0.6f,
                    size.width * 0.45f, size.height
                )
            }
            drawPath(
                path = nilePath,
                color = Color(0xFF90CAF9).copy(alpha = 0.55f),
                style = Stroke(width = 16f)
            )

            // Factory Pin (Center)
            drawCircle(
                color = Color(0xFF263238),
                radius = 14f,
                center = center
            )
            drawCircle(
                color = Color.White,
                radius = 6f,
                center = center
            )
        }

        // Factory Pin Label
        Box(
            modifier = Modifier
                .align(Alignment.Center)
                .padding(bottom = 60.dp)
                .clip(RoundedCornerShape(6.dp))
                .background(Color(0xFF263238))
                .padding(horizontal = 6.dp, vertical = 2.dp)
        ) {
            Text("🏭 مصنعك (قوص)", color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.Bold)
        }

        // Simulated Geo-pins for listings around Nile Valley
        listings.forEachIndexed { index, listing ->
            val isSelected = listing.id == selectedListing?.id
            val offsetX = when (index % 5) {
                0 -> 0.62f
                1 -> 0.32f
                2 -> 0.70f
                3 -> 0.28f
                else -> 0.52f
            }
            val offsetY = when (index % 5) {
                0 -> 0.32f
                1 -> 0.55f
                2 -> 0.62f
                3 -> 0.25f
                else -> 0.42f
            }

            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(
                        start = (offsetX * 280).dp,
                        top = (offsetY * 280).dp
                    )
            ) {
                Surface(
                    shape = CircleShape,
                    color = if (isSelected) SfairAmberSecondary else SfairGreenPrimary,
                    shadowElevation = 6.dp,
                    modifier = Modifier
                        .size(if (isSelected) 46.dp else 38.dp)
                        .clickable { onSelectListing(listing) }
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Text(
                            text = "${listing.estimatedTons.toInt()}ط",
                            color = Color.White,
                            fontSize = if (isSelected) 12.sp else 11.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun BuyerListingCard(
    listing: WasteListing,
    audioController: AudioController,
    isCompact: Boolean,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val currentPlayingId by audioController.currentPlayingListingId.collectAsState()
    val isPlaying by audioController.isPlaying.collectAsState()
    val progress by audioController.playingProgress.collectAsState()

    val isThisAudioPlaying = isPlaying && currentPlayingId == listing.id

    Card(
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 3.dp),
        modifier = modifier
            .fillMaxWidth()
            .border(1.dp, Color(0xFFE0E0E0), RoundedCornerShape(18.dp))
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            // Header Row: Waste Badge + Farmer + Distance
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = Color(listing.wasteType.badgeColor).copy(alpha = 0.15f)
                    ) {
                        Text(
                            text = "${listing.wasteType.iconEmoji} ${listing.wasteType.titleArabic}",
                            color = Color(listing.wasteType.badgeColor),
                            fontWeight = FontWeight.Bold,
                            fontSize = 12.sp,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = Color(0xFFFFF3E0)
                    ) {
                        Text(
                            text = "${listing.distanceKm} كم عنك",
                            color = Color(0xFFE65100),
                            fontWeight = FontWeight.Bold,
                            fontSize = 11.sp,
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 4.dp)
                        )
                    }
                }

                Text(
                    text = listing.timeAgoArabic,
                    fontSize = 11.sp,
                    color = Color.Gray
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Main Details Row: Farmer Name, Village, Tonnage
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = listing.farmerName,
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF263238)
                    )
                    Text(
                        text = "📍 ${listing.villageName}",
                        fontSize = 12.sp,
                        color = Color(0xFF546E7A)
                    )
                }

                Column(horizontalAlignment = Alignment.End) {
                    Text(
                        text = "${listing.estimatedTons} طن",
                        fontSize = 18.sp,
                        fontWeight = FontWeight.ExtraBold,
                        color = SfairGreenPrimary
                    )
                    Text(
                        text = listing.pricePerTonEgp,
                        fontSize = 11.sp,
                        color = Color(0xFF455A64)
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Audio Player Component
            AudioPlayerCard(
                audioDurationSec = listing.audioDurationSeconds,
                isPlaying = isThisAudioPlaying,
                progress = if (isThisAudioPlaying) progress else 0f,
                onTogglePlay = {
                    if (isThisAudioPlaying) {
                        audioController.stopPlaying()
                    } else {
                        audioController.playAudio(listing.audioFileUri, listing.id)
                    }
                },
                farmerTranscription = listing.voiceTranscription
            )

            Spacer(modifier = Modifier.height(12.dp))

            // Action Buttons: Direct Call & WhatsApp
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Button(
                    onClick = { launchPhoneCall(context, listing.farmerPhone) },
                    colors = ButtonDefaults.buttonColors(containerColor = SfairGreenPrimary),
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier.weight(1f).testTag("call_farmer_btn")
                ) {
                    Icon(Icons.Default.Call, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("اتصال هاتفي", fontSize = 13.sp, fontWeight = FontWeight.Bold)
                }

                Button(
                    onClick = {
                        val msg = "السلام عليكم يا حاج ${listing.farmerName}، شفت عرضك على تطبيق سفير بخصوص ${listing.estimatedTons} طن ${listing.wasteType.titleArabic} في ${listing.villageName}، وحابب نتفق على الاستلام."
                        launchWhatsApp(context, listing.farmerPhone, msg)
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF25D366)),
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier.weight(1f).testTag("whatsapp_farmer_btn")
                ) {
                    Text("💬 واتساب", color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}
