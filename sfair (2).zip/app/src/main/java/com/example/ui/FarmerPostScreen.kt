package com.example.ui

import android.Manifest
import android.content.pm.PackageManager
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.example.audio.AudioController
import com.example.model.PackagingType
import com.example.model.UpperEgyptVillages
import com.example.model.WasteListing
import com.example.model.WasteType
import com.example.ui.theme.SfairAmberSecondary
import com.example.ui.theme.SfairGreenPrimary
import com.example.ui.theme.SfairMicActive
import java.io.File

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun FarmerPostScreen(
    audioController: AudioController,
    onOfferCreated: (WasteListing) -> Unit,
    onNavigateToBuyer: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val isRecording by audioController.isRecording.collectAsState()
    val recordingDuration by audioController.recordingDuration.collectAsState()
    val amplitudes by audioController.amplitudes.collectAsState()
    val isPlaying by audioController.isPlaying.collectAsState()
    val playProgress by audioController.playingProgress.collectAsState()

    var selectedWasteType by remember { mutableStateOf(WasteType.SUGARCANE_TRASH) }
    var recordedFile by remember { mutableStateOf<File?>(null) }
    var recordedDurationSeconds by remember { mutableStateOf(0) }
    var transcriptionText by remember {
        mutableStateOf<String?>(null)
    }

    var selectedVillage by remember { mutableStateOf(UpperEgyptVillages[0]) }
    var isVillageDropdownExpanded by remember { mutableStateOf(false) }
    var showSuccessDialog by remember { mutableStateOf(false) }
    var showVoicePromptDialog by remember { mutableStateOf(false) }

    // Audio recording permission launcher
    val recordAudioPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { isGranted ->
        if (isGranted) {
            audioController.startRecording(
                onSuccess = { file -> recordedFile = file },
                onError = { msg -> Toast.makeText(context, msg, Toast.LENGTH_SHORT).show() }
            )
        } else {
            // Still allow simulated recording so low-literacy testing is never blocked
            audioController.startRecording(
                onSuccess = { file -> recordedFile = file },
                onError = { }
            )
        }
    }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(Color(0xFFF7FAF7))
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Spacer(modifier = Modifier.height(8.dp))
            // Voice Guidance Welcome Bar for Illiterate Users
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFFE8F5E9)),
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { showVoicePromptDialog = true }
                    .border(1.dp, Color(0xFFA5D6A7), RoundedCornerShape(16.dp))
            ) {
                Row(
                    modifier = Modifier.padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Surface(
                        shape = CircleShape,
                        color = SfairGreenPrimary,
                        modifier = Modifier.size(42.dp)
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Icon(
                                Icons.Default.VolumeUp,
                                contentDescription = "استمع للإرشادات",
                                tint = Color.White
                            )
                        }
                    }
                    Spacer(modifier = Modifier.width(12.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "🔊 اضغط هنا للاستماع للتعليمات صوتياً",
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp,
                            color = SfairGreenPrimary
                        )
                        Text(
                            text = "سهلناها عليك: كل اللي عليك تضغط المايك وتسجل بصوتك",
                            fontSize = 12.sp,
                            color = Color(0xFF388E3C)
                        )
                    }
                }
            }
        }

        // 1. Choose Crop Waste
        item {
            Column {
                Text(
                    text = "١. اختر نوع المخلف الزراعي",
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFF1B5E20)
                )
                Spacer(modifier = Modifier.height(10.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    WasteTypeCard(
                        type = WasteType.SUGARCANE_TRASH,
                        isSelected = selectedWasteType == WasteType.SUGARCANE_TRASH,
                        onClick = { selectedWasteType = WasteType.SUGARCANE_TRASH },
                        modifier = Modifier.weight(1f)
                    )
                    WasteTypeCard(
                        type = WasteType.SUGARCANE_BAGASSE,
                        isSelected = selectedWasteType == WasteType.SUGARCANE_BAGASSE,
                        onClick = { selectedWasteType = WasteType.SUGARCANE_BAGASSE },
                        modifier = Modifier.weight(1f)
                    )
                }

                Spacer(modifier = Modifier.height(10.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    WasteTypeCard(
                        type = WasteType.RICE_STRAW,
                        isSelected = selectedWasteType == WasteType.RICE_STRAW,
                        onClick = { selectedWasteType = WasteType.RICE_STRAW },
                        modifier = Modifier.weight(1f)
                    )
                    WasteTypeCard(
                        type = WasteType.CORN_STALKS,
                        isSelected = selectedWasteType == WasteType.CORN_STALKS,
                        onClick = { selectedWasteType = WasteType.CORN_STALKS },
                        modifier = Modifier.weight(1f)
                    )
                }
            }
        }

        // 2. Central High-Visibility Microphone Recording
        item {
            Card(
                shape = RoundedCornerShape(24.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(
                        2.dp,
                        if (isRecording) SfairMicActive else Color(0xFFE0E0E0),
                        RoundedCornerShape(24.dp)
                    )
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(20.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = "٢. سجل عرضك بصوتك (المايك)",
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF1B5E20)
                    )

                    Spacer(modifier = Modifier.height(6.dp))

                    Text(
                        text = if (isRecording) "جاري التسجيل... قول عندك كام طن وفين مكانك"
                        else if (recordedFile != null) "تم تسجيل صوتك بنجاح! اسمع تسجيلك بالأسفل"
                        else "اضغط على الزر الأحمر الكبير واتكلم على طول",
                        fontSize = 13.sp,
                        color = if (isRecording) SfairMicActive else Color(0xFF555555),
                        textAlign = TextAlign.Center
                    )

                    Spacer(modifier = Modifier.height(16.dp))

                    // Huge Pulsing Mic Button
                    val infiniteTransition = rememberInfiniteTransition(label = "pulse")
                    val pulseScale by infiniteTransition.animateFloat(
                        initialValue = 1.0f,
                        targetValue = if (isRecording) 1.15f else 1.05f,
                        animationSpec = infiniteRepeatable(
                            animation = tween(600, easing = FastOutSlowInEasing),
                            repeatMode = RepeatMode.Reverse
                        ),
                        label = "micPulse"
                    )

                    Box(
                        contentAlignment = Alignment.Center,
                        modifier = Modifier
                            .size(110.dp)
                            .scale(pulseScale)
                    ) {
                        // Outer ripple wave
                        if (isRecording) {
                            Box(
                                modifier = Modifier
                                    .size(110.dp)
                                    .clip(CircleShape)
                                    .background(Color(0xFFFFCDD2).copy(alpha = 0.6f))
                            )
                        }

                        // Main circular button
                        Surface(
                            shape = CircleShape,
                            color = if (isRecording) SfairMicActive else Color(0xFFD32F2F),
                            shadowElevation = 6.dp,
                            modifier = Modifier
                                .size(92.dp)
                                .clip(CircleShape)
                                .clickable {
                                    if (isRecording) {
                                        val file = audioController.stopRecording()
                                        recordedFile = file
                                        recordedDurationSeconds = recordingDuration
                                        transcriptionText = when (selectedWasteType) {
                                            WasteType.SUGARCANE_TRASH -> "عندي حوالي ٥ طن سفير قصب سكر ناشف وجاهز في ${selectedVillage}، تواصلوا معايا للتحميل."
                                            WasteType.SUGARCANE_BAGASSE -> "متاح كمية من مصاصة القصب من المعصرة في ${selectedVillage}."
                                            WasteType.RICE_STRAW -> "عندي قش أرز مكبوس ببالات للبيع في ${selectedVillage}."
                                            WasteType.CORN_STALKS -> "حطب ذرة مجفف ممتاز للوقود والأعلاف في ${selectedVillage}."
                                        }
                                        Toast.makeText(context, "تم حفظ التسجيل الصوتي!", Toast.LENGTH_SHORT).show()
                                    } else {
                                        val hasPermission = ContextCompat.checkSelfPermission(
                                            context,
                                            Manifest.permission.RECORD_AUDIO
                                        ) == PackageManager.PERMISSION_GRANTED

                                        if (hasPermission) {
                                            audioController.startRecording(
                                                onSuccess = { file -> recordedFile = file },
                                                onError = { }
                                            )
                                        } else {
                                            recordAudioPermissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
                                        }
                                    }
                                }
                                .testTag("mic_recording_button")
                        ) {
                            Column(
                                horizontalAlignment = Alignment.CenterHorizontally,
                                verticalArrangement = Arrangement.Center
                            ) {
                                Icon(
                                    imageVector = if (isRecording) Icons.Default.Stop else Icons.Default.Mic,
                                    contentDescription = if (isRecording) "إيقاف التسجيل" else "بدء تسجيل صوتي",
                                    tint = Color.White,
                                    modifier = Modifier.size(42.dp)
                                )
                                Text(
                                    text = if (isRecording) "إيقاف" else "اضغط واتكلم",
                                    color = Color.White,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    if (isRecording) {
                        Text(
                            text = "0:${String.format("%02d", recordingDuration)} / 01:30",
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold,
                            color = SfairMicActive
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        AudioWaveformVisualizer(
                            isRecording = true,
                            amplitudes = amplitudes
                        )
                    } else if (recordedFile != null) {
                        AudioPlayerCard(
                            audioDurationSec = if (recordedDurationSeconds > 0) recordedDurationSeconds else 18,
                            isPlaying = isPlaying,
                            progress = playProgress,
                            onTogglePlay = {
                                if (isPlaying) {
                                    audioController.stopPlaying()
                                } else {
                                    audioController.playAudio(recordedFile?.absolutePath)
                                }
                            },
                            farmerTranscription = transcriptionText
                        )

                        Spacer(modifier = Modifier.height(10.dp))

                        TextButton(
                            onClick = {
                                recordedFile = null
                                transcriptionText = null
                                audioController.stopPlaying()
                            }
                        ) {
                            Icon(Icons.Default.Refresh, contentDescription = null, tint = Color.Gray)
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("إعادة التسجيل بصوت آخر", color = Color.Gray, fontSize = 13.sp)
                        }
                    }
                }
            }
        }

        // 3. Location & Village Selector
        item {
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, Color(0xFFE0E0E0), RoundedCornerShape(16.dp))
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            Icons.Default.LocationOn,
                            contentDescription = null,
                            tint = SfairGreenPrimary
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "٣. تحديد القرية والموقع",
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF1B5E20)
                        )
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(10.dp))
                            .background(Color(0xFFE8F5E9))
                            .padding(horizontal = 12.dp, vertical = 8.dp)
                    ) {
                        Text(
                            text = "📍 تم التقاط إحداثيات موقعك في الحقل تلقائياً عبر GPS",
                            fontSize = 12.sp,
                            color = Color(0xFF2E7D32),
                            fontWeight = FontWeight.SemiBold
                        )
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Text(
                        text = "اختر أقرب مركز أو قرية لك:",
                        fontSize = 13.sp,
                        color = Color(0xFF455A64)
                    )

                    Spacer(modifier = Modifier.height(6.dp))

                    ExposedDropdownMenuBox(
                        expanded = isVillageDropdownExpanded,
                        onExpandedChange = { isVillageDropdownExpanded = !isVillageDropdownExpanded }
                    ) {
                        OutlinedTextField(
                            value = selectedVillage,
                            onValueChange = {},
                            readOnly = true,
                            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = isVillageDropdownExpanded) },
                            modifier = Modifier
                                .menuAnchor()
                                .fillMaxWidth(),
                            shape = RoundedCornerShape(12.dp)
                        )
                        ExposedDropdownMenu(
                            expanded = isVillageDropdownExpanded,
                            onDismissRequest = { isVillageDropdownExpanded = false }
                        ) {
                            UpperEgyptVillages.forEach { village ->
                                DropdownMenuItem(
                                    text = { Text(village, fontSize = 14.sp) },
                                    onClick = {
                                        selectedVillage = village
                                        isVillageDropdownExpanded = false
                                    }
                                )
                            }
                        }
                    }
                }
            }
        }

        // 4. Giant Submit Button
        item {
            Button(
                onClick = {
                    val newListing = WasteListing(
                        id = System.currentTimeMillis().toString(),
                        farmerName = "مزارع (عرضك الجديد)",
                        farmerPhone = "01000000000",
                        wasteType = selectedWasteType,
                        estimatedTons = 5.0,
                        villageName = selectedVillage,
                        distanceKm = 4.2,
                        audioDurationSeconds = if (recordedDurationSeconds > 0) recordedDurationSeconds else 20,
                        audioFileUri = recordedFile?.absolutePath,
                        voiceTranscription = transcriptionText ?: "عندي 5 طن ${selectedWasteType.titleArabic} في $selectedVillage جاهز للتحميل والتوريد للمصانع.",
                        packaging = PackagingType.BALED,
                        hasOwnTransport = true,
                        pricePerTonEgp = "سعر تفاوضي",
                        timeAgoArabic = "الآن"
                    )
                    onOfferCreated(newListing)
                    showSuccessDialog = true
                },
                shape = RoundedCornerShape(16.dp),
                colors = ButtonDefaults.buttonColors(containerColor = SfairGreenPrimary),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(60.dp)
                    .testTag("publish_offer_button")
            ) {
                Icon(
                    Icons.Default.CheckCircle,
                    contentDescription = null,
                    modifier = Modifier.size(24.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "✓ انشر العرض الآن للمصانع",
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold
                )
            }
            Spacer(modifier = Modifier.height(24.dp))
        }
    }

    // Success Dialog
    if (showSuccessDialog) {
        AlertDialog(
            onDismissRequest = { showSuccessDialog = false },
            title = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        Icons.Default.CheckCircle,
                        contentDescription = null,
                        tint = SfairGreenPrimary,
                        modifier = Modifier.size(32.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("تم نشر عرضك بنجاح!", fontWeight = FontWeight.Bold)
                }
            },
            text = {
                Column {
                    Text(
                        text = "وصل تسجيلك الصوتي للمصانع ومكابس الورق والأعلاف القريبة من قريتك ($selectedVillage). سيتواصل معك أصحاب المصانع هاتفياً أو عبر واتساب.",
                        lineHeight = 22.sp,
                        fontSize = 14.sp
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "يمكنك التبديل لوضع 'المصنع' بالأعلى لترى كيف يظهر عرضك على خريطة المشتري!",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = SfairAmberSecondary
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        showSuccessDialog = false
                        onNavigateToBuyer()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = SfairGreenPrimary)
                ) {
                    Text("عرض على خريطة المصانع")
                }
            },
            dismissButton = {
                TextButton(onClick = { showSuccessDialog = false }) {
                    Text("إغلاق")
                }
            }
        )
    }

    // Voice Guidance Audio Dialog
    if (showVoicePromptDialog) {
        AlertDialog(
            onDismissRequest = { showVoicePromptDialog = false },
            title = {
                Text("إرشادات صوتية للمزارع", fontWeight = FontWeight.Bold, color = SfairGreenPrimary)
            },
            text = {
                Column {
                    Text(
                        text = "« أهلاً بيك يا حاج.. التطبيق معمول علشانك ومفيش داعي للكتابة:\n\n١. اختار نوع المخلف (سفير قصب، مصاصة، قش أرز).\n٢. اضغط على المايك الأحمر واتكلم وقول عندك كام طن ومكان أرضك فين.\n٣. اضغط زرار النشر الأخضر، ومندوب المصنع هيتصل بيك فوراً! »",
                        lineHeight = 22.sp,
                        fontSize = 15.sp,
                        color = Color(0xFF263238)
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = { showVoicePromptDialog = false },
                    colors = ButtonDefaults.buttonColors(containerColor = SfairGreenPrimary)
                ) {
                    Text("تمام، فهمت")
                }
            }
        )
    }
}

@Composable
fun WasteTypeCard(
    type: WasteType,
    isSelected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (isSelected) Color(0xFFE8F5E9) else Color.White
        ),
        modifier = modifier
            .border(
                width = if (isSelected) 2.dp else 1.dp,
                color = if (isSelected) SfairGreenPrimary else Color(0xFFE0E0E0),
                shape = RoundedCornerShape(16.dp)
            )
            .clickable(onClick = onClick)
    ) {
        Column(
            modifier = Modifier.padding(12.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Box(
                modifier = Modifier
                    .size(44.dp)
                    .clip(CircleShape)
                    .background(
                        if (isSelected) Color(type.badgeColor).copy(alpha = 0.2f) else Color(0xFFF5F5F5)
                    ),
                contentAlignment = Alignment.Center
            ) {
                Text(text = type.iconEmoji, fontSize = 22.sp)
            }
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = type.titleArabic,
                fontSize = 15.sp,
                fontWeight = FontWeight.Bold,
                color = if (isSelected) SfairGreenPrimary else Color(0xFF212121),
                textAlign = TextAlign.Center
            )
            Spacer(modifier = Modifier.height(2.dp))
            Text(
                text = type.avgDensityTonsPerFeddan,
                fontSize = 11.sp,
                color = Color.Gray,
                textAlign = TextAlign.Center
            )
        }
    }
}
