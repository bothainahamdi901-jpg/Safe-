package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Light Scheme Colors
val SfairGreenPrimary = Color(0xFF1B5E20)
val SfairGreenOnPrimary = Color(0xFFFFFFFF)
val SfairGreenContainer = Color(0xFFC8E6C9)
val SfairGreenOnContainer = Color(0xFF002105)

val SfairAmberSecondary = Color(0xFFF57F17)
val SfairAmberOnSecondary = Color(0xFFFFFFFF)
val SfairAmberContainer = Color(0xFFFFECB3)
val SfairAmberOnContainer = Color(0xFF261900)

val SfairEarthTertiary = Color(0xFF5D4037)
val SfairEarthOnTertiary = Color(0xFFFFFFFF)
val SfairEarthContainer = Color(0xFFD7CCC8)
val SfairEarthOnContainer = Color(0xFF1E1410)

val SfairBackground = Color(0xFFF7FAF7)
val SfairOnBackground = Color(0xFF181C19)
val SfairSurface = Color(0xFFFFFFFF)
val SfairOnSurface = Color(0xFF181C19)
val SfairSurfaceVariant = Color(0xFFE0E5DF)
val SfairOnSurfaceVariant = Color(0xFF424940)

// Highlight / Mic Pulsing Colors
val SfairMicActive = Color(0xFFD32F2F)
val SfairMicRipple = Color(0xFFFFCDD2)
val SfairCardBorder = Color(0xFFE0E0E0)

// Dark Scheme Colors
val SfairGreenDark = Color(0xFF81C784)
val SfairGreenOnDark = Color(0xFF00390F)
val SfairAmberDark = Color(0xFFFFD54F)
val SfairAmberOnDark = Color(0xFF402D00)
val SfairBackgroundDark = Color(0xFF111412)
val SfairSurfaceDark = Color(0xFF191C1A)

