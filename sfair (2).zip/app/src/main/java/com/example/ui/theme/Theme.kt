package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable

private val DarkColorScheme = darkColorScheme(
    primary = SfairGreenDark,
    onPrimary = SfairGreenOnDark,
    primaryContainer = SfairGreenPrimary,
    onPrimaryContainer = SfairGreenContainer,
    secondary = SfairAmberDark,
    onSecondary = SfairAmberOnDark,
    background = SfairBackgroundDark,
    surface = SfairSurfaceDark
)

private val LightColorScheme = lightColorScheme(
    primary = SfairGreenPrimary,
    onPrimary = SfairGreenOnPrimary,
    primaryContainer = SfairGreenContainer,
    onPrimaryContainer = SfairGreenOnContainer,
    secondary = SfairAmberSecondary,
    onSecondary = SfairAmberOnSecondary,
    secondaryContainer = SfairAmberContainer,
    onSecondaryContainer = SfairAmberOnContainer,
    tertiary = SfairEarthTertiary,
    onTertiary = SfairEarthOnTertiary,
    background = SfairBackground,
    onBackground = SfairOnBackground,
    surface = SfairSurface,
    onSurface = SfairOnSurface,
    surfaceVariant = SfairSurfaceVariant,
    onSurfaceVariant = SfairOnSurfaceVariant
)

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    dynamicColor: Boolean = false,
    content: @Composable () -> Unit,
) {
    val colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}

